package com.example.scw;

        import androidx.annotation.NonNull;
        import androidx.appcompat.app.AppCompatActivity;
        import androidx.fragment.app.DialogFragment;
        import androidx.navigation.NavController;
        import androidx.navigation.Navigation;
        import androidx.navigation.ui.NavigationUI;

        import android.content.Intent;
        import android.os.Bundle;
        import android.view.Menu;
        import android.view.MenuItem;
        import android.view.View;
        import android.widget.Button;
        import android.widget.PopupMenu;
        import android.widget.TextView;
        import android.widget.Toast;

        import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNavigationView = findViewById(R.id.BottomNavigationView);
        NavController navController = Navigation.findNavController(this,  R.id.fragment);
        NavigationUI.setupWithNavController(bottomNavigationView, navController);


        TextView a = findViewById(R.id.textView);
        Button b = findViewById(R.id.button);

        a.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDialog();
            }
        });
    }

    public void openDialog() {
        DialogBox Y = new DialogBox();
        Y.show(getSupportFragmentManager(), "Z");
    }

    public void showPopup(View v) {
        PopupMenu popup = new PopupMenu(this, v);
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.facts_menu);
        popup.show();

    }

    @Override
    public boolean onMenuItemClick(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.A:
                Toast.makeText(this, "There’s a Time Jump", Toast.LENGTH_SHORT).show();
            case R.id.B:
                Toast.makeText(this, "The Skywalker Lightsaber Is Back", Toast.LENGTH_SHORT).show();
            case R.id.C:
                Toast.makeText(this, "Lando’s New Costume Is a Callback to Solo", Toast.LENGTH_SHORT).show();
            default:
                return false;
        }
    }
}

